import base.HealthProfessional;
import child.Dentist;
import child.GeneralPractitioner;
//import 3 classes

public class Appointment
{
    private String PatientName;
    private String PhoneNumber;
    private String PreferredTimeSlot;
    //Difine variables for patient name, phone number , appointment time
    private HealthProfessional doctor;
    //Quoting the variable from HealthProfessional forndoctor information

    public Appointment()
    {
        //Default constructor
        this.PatientName = PatientName;
        this.PhoneNumber = PhoneNumber;
        this.PreferredTimeSlot = PreferredTimeSlot;
        this.doctor = null;
    }

    public Appointment(String PatientName, String PhoneNumber, String PreferredTimeSlot, HealthProfessional doctor)
    {
        this.PatientName = PatientName;
        this.PhoneNumber = PhoneNumber;
        this.PreferredTimeSlot = PreferredTimeSlot;
        this.doctor = doctor;
    }

    public void printAppointmentDetails()
    {
        System.out.println("Patient Name :" +PatientName);
        System.out.println("Phone :" +PhoneNumber);
        System.out.println("Prefer time slot :" +PreferredTimeSlot);
        //Print the patients personal information first
        if( doctor != null)
        {
            System.out.println("Doctor information :");
            doctor.printInfo();
        }
        else
        {
            System.out.println("No doctor can be selected now !");
        }
        System.out.println("--------");
        //After that , using if statement to print the doctors details , if the valua is null , the patient can not select doctor
    }

    public String getPhoneNumber()
    {
        return PhoneNumber;
        //Getters for getting the phone number
    }

    public static void main(String args[])
    {
        //Create object and appointments here ( Existing information )(Only one object for testing)
        //GeneralPractitioner gpx = new GeneralPractitioner(523, "Max","Family Medicine Specialist", "Family Medicine");
        //Appointment apx = new Appointment("Sarah","13241432","7:00 - 10 :00", gpx);
        //System.out.println("Appointments for patients information is here :");
        //apx.printAppointmentDetails();
        
        //2 general doctor object appointments and 2 dentist appointments here: (4 objects)
        GeneralPractitioner gp1 = new GeneralPractitioner(156, "Dr.Karlie", "Family Medicine Specialist", "Family Medicie");
        Appointment ap1 = new Appointment("David","19999999","8:00 - 10:00",gp1);
        System.out.println("Appointments for patients information is here :");
        ap1.printAppointmentDetails();
        GeneralPractitioner gp2 = new GeneralPractitioner(157,"Dr.Jimmy","Chemical biology technology", "Doctor technology");
        Appointment ap2 = new Appointment("Fridge", "19999327", "9:00 - 11:00", gp2);
        ap2.printAppointmentDetails();
        Dentist dt1 = new Dentist(162, "Dr.Nek", "Orthopedic specialist", "Orthopedic specialist");
        Appointment ap3 = new Appointment("Green", "13332994", "7:00-13:00", dt1);
        ap3.printAppointmentDetails();
        Dentist dt2 = new Dentist(163,"Dr.Jude", "Stomatology", "Dentist techonology" );
        Appointment ap4 = new Appointment("Alice", "31992254", "9:00-10:00", dt2);
        ap4.printAppointmentDetails();
    }



}
