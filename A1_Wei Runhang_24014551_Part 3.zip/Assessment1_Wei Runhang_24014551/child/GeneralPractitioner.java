package child;

import base.HealthProfessional; //The method of inheriting HealthProfessional (in the base package)

public class GeneralPractitioner extends HealthProfessional
{

   private String specialty; //An instance variable will be defined as a general practitioner

   public GeneralPractitioner()
   {
      super();
      this.specialty = "General Practice" ; //Assign a value to a type : General Practice
   }

   public GeneralPractitioner(int ID, String name, String basicInfo, String specialty)
   {
      super(ID,name,basicInfo); 
      //I have inherited the HealthProfessional class, so these three variables can be used
      //Use the super method to call the father class method and inherit three variables
      this.specialty = specialty;
   }
    

   @Override
   ////Rewrite printInfo method by override method
   public void printInfo()
   {
      super.printInfo();
      System.out.println("Specialty :"  + specialty);
   }

}
