//My Github link : https://github.com/Blue2581/java1 
//Notice that : You need to use a vpn to visit Github link
//Created a HealthProfessional class in the base class for part 1 task
package base; // HealthProfessional class is in base package ( New change )
import child.Dentist;
import child.GeneralPractitioner;


public class HealthProfessional 
{
    private int ID; 
    //Required instance variable ID
    private String name;
    //Required instance variable name
    private String basicInfo;
    //Basic information unrelated to the type of doctor

    public HealthProfessional() 
    {
        //The default constructor of the first function 
        this.ID = 0;
        this.name = "";
        this.basicInfo = "";
        //In this method, default values can be set for these three variables. ("Null" is also ok)
       
    }

    public HealthProfessional(int ID, String name, String basicInfo) 
    {
        //The second function , Initialize all instance variables
        this.ID = ID;
        this.name = name;
        this.basicInfo = basicInfo;

    }

    public void printInfo()
    {
        System.out.println("ID :" +this.ID);
        System.out.println("name :" +this.name);
        System.out.println("basciInfo :" +this.basicInfo);
        //This method can output the values of all variables : ID, name and basciInfo
    }

    //Getters and Setters : Get the property values of three variables (Getters), and then modify them using Setters
    public int getID()
    {
        return ID;
    }

    public void setID(int ID)
    {
        this.ID = ID;
    }

    public String getname()
    {
        return name;
    }

    public void setname(String name)
    {
        this.name = name;
    }

    public String getbasicInfo()
    {
        return basicInfo;
    }

    public void setbasicInfo(String basicInfo)
    {
        this.basicInfo = basicInfo;
    }

    //Create 5 objects using the main method: 3 general practitioners, 2 dentists
    public static void main(String[] args)
    {
        //First, test whether these three variables can output normally
        //HealthProfessional professional = new HealthProfessional(215,"Dr.smith","General Practioner");
        //professional.printInfo();

        //Create a GeneralPractitioner object and a Dentist object in this area( Part 2)
        GeneralPractitioner generalPractitioner = new GeneralPractitioner(308, "Dr.John","Experienced GP","Family Medicine");
        generalPractitioner.printInfo();
        Dentist dentist = new Dentist(743,"Dr.Emily","Expert in dental care","Smile Bright Clinic");
        dentist.printInfo();
    }



}
