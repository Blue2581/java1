package child;
//My Github link : https://github.com/Blue2581/java1 
import base.HealthProfessional;
 //The method of inheriting HealthProfessional (in the base package)
public class Dentist extends HealthProfessional
{
    private String clinicName;
    //Define a variable: clinic name, I will assign it  later

    public Dentist()
    {
        super();
        this.clinicName = "Unkonwn Clinic";//Assign valua
    }

    public Dentist(int ID, String name, String basicInfo, String clinicName)
    {
        //Parameterized constructor
        super(ID, name, basicInfo);
         //I have inherited the HealthProfessional class, so these three variables can be used
         //Use the super method to call the father class method and inherit three variables
        this.clinicName = clinicName;

    }

    @Override
    //Rewrite printInfo method by override method
    public void printInfo()
    {
        super.printInfo();
        System.out.println("clinicName :" +clinicName);
    }
}