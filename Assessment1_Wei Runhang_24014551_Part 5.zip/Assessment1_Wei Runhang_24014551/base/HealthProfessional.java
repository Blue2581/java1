//My Github link : https://github.com/Blue2581/java1 
//Notice that : You need to use a vpn to visit Github link
//Created a HealthProfessional class in the base class for part 1 task
package base; // HealthProfessional class is in base package ( New change )
import child.Dentist;
import child.GeneralPractitioner;


public class HealthProfessional 
{
    private int ID; 
    //Required instance variable ID
    private String name;
    //Required instance variable name
    private String basicInfo;
    //Basic information unrelated to the type of doctor

    public HealthProfessional() 
    {
        //The default constructor of the first function 
        this.ID = 0;
        this.name = "";
        this.basicInfo = "";
        //In this method, default values can be set for these three variables. ("Null" is also ok)
       
    }

    public HealthProfessional(int ID, String name, String basicInfo)
    {
        //The second function , Initialize all instance variables
        this.ID = ID;
        this.name = name;
        this.basicInfo = basicInfo;

    }

    public void printInfo()
    {
        System.out.println("ID :" +this.ID);
        System.out.println("name :" +this.name);
        System.out.println("basciInfo :" +this.basicInfo);
        //This method can output the values of all variables : ID, name and basciInfo
    }

    //Getters and Setters : Get the property values of three variables (Getters), and then modify them using Setters
    public int getID()
    {
        return ID;
    }

    public void setID(int ID)
    {
        this.ID = ID;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getbasicInfo()
    {
        return basicInfo;
    }

    public void SetbasicInfo(String basciInfo)
    {
        this.basicInfo = basicInfo;
    }

    //Create 5 objects using the main method: 3 general practitioners, 2 dentists
    public static void main(String[] args)
    {
        //Part 1
        //First, test whether these three variables can output normally
        //HealthProfessional professional = new HealthProfessional(715,"Dr.Smith","General Practioner");
        //professional.printInfo();

        //Part 2
        //Create a GeneralPractitioner object and a Dentist object in this area
        //GeneralPractitioner generalPractitioner = new GeneralPractitioner(156,"Dr.John", "Experienced GP","Family Medicine");
        //generalPractitioner.printInfo();
        //Dentist dentist = new Dentist(743,"Dr.Emily","Expert in dental care","Smilem Bright Clinic");
        //dentist.printInfo();

        //Part 3 : Create 5 objects : 3 GeneralPractioner doctors and 2 dentists
        GeneralPractitioner gp1 = new GeneralPractitioner(111, "Dr.Alice", "Experienced in Family medicine", "Family Medicine");
        GeneralPractitioner gp2 = new GeneralPractitioner(112, "Dr.Bob", "Expert in community health", "Community Health");
        GeneralPractitioner gp3 = new GeneralPractitioner(113, "Dr.Carol", "Specialist in preventive care", "Preventive Care");
        Dentist dt1 = new Dentist(171, "Dr.Jack", "Expert in dental surgey", "Bright Smile Clinic");
        Dentist dt2 = new Dentist(172, "Dr.Dave", "Specialist in pediatric dentistry", "Kids Dental Care");

        //Print 5 objects information : 3 GeneralPractioner doctors and 2 dentists information
        System.out.println("General Practitioner:");
        gp1.printInfo();
        System.out.println("--------");
        gp2.printInfo();
        System.out.println("--------");
        gp3.printInfo();
        System.out.println("--------");
        dt1.printInfo();
        System.out.println("--------");
        dt2.printInfo();
        System.out.println("--------");

    }



}
