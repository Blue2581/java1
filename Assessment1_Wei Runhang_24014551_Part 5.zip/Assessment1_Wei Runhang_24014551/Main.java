import base.HealthProfessional;
import child.Dentist;
import child.GeneralPractitioner;
import java.util.ArrayList;
import java.util.Scanner;

//My Github link : https://guthub.com/Blue2581/java1
public class Main
{   
    
    // Part 5-Collection of appointments
    private static ArrayList<Appointment> appointments = new ArrayList<>();

    public static void main(String[] args) 
    {
        Scanner scanner = new Scanner(System.in);

        //Create some doctor objects
        GeneralPractitioner gp = new GeneralPractitioner(101, "Dr. Alice", "Family Medicine Specialist", "Family Medicine");
        Dentist dentist = new Dentist(201, "Dr. Bob", "Expert in dental care", "Bright Smile Clinic");

        //Create and add some default appointments
        createAppointment("John Doe", "123-456-7890", "09:00-10:00", gp);
        createAppointment("Jane Smith", "987-654-3210", "14:00-15:00", dentist);

        //Print existing appointments
        System.out.println("Existing Appointments:");
        printExistingAppointments();

        System.out.println("---------");

        //User interaction: Create a new appointment
        System.out.println("Do you want to create a new appointment? (yes/no)");
        String response = scanner.nextLine();
        if(response.equalsIgnoreCase("yes"))
        {
            System.out.print("Enter patient name: ");
            String patientName = scanner.nextLine();

            System.out.print("Enter phone number: ");
            String phoneNumber = scanner.nextLine();

            System.out.print("Enter prefered time slot: ");
            String preferedTimeSlot = scanner.nextLine();

            System.out.print("Choose doctor type (1 for General Practioner, 2 for Dentist): ");
            int doctorChoice = scanner.nextInt();
            scanner.nextLine(); //Clear line breaks

            HealthProfessional doctor = null;
            if (doctorChoice == 1)
            {
                doctor = gp;
            }
            else if (doctorChoice == 2)
            {
                doctor = dentist;
            }
            else 
            {
                System.out.println("Invalid doctor choice.");
            }

            if (doctor != null)
            {
                createAppointment(patientName, phoneNumber, preferedTimeSlot, doctor);
            }
        }

        System.out.println("---------");

        //Print all appointments
        System.out.println("All Appointments: ");
        printExistingAppointments();

        System.out.println("---------");

        //User interaction: Cancel reservation
        System.out.print("Enter phone number to cancel booking: ");
        String cancelPhoneNumber = scanner.nextLine();
        cancelBooking(cancelPhoneNumber);

        System.out.println("---------");

        //Print cancelled appointments
        System.out.println("Appointments after cancellation:");
        printExistingAppointments();    

        scanner.close();       
    }

    //Create a new appointment and add it to the ArrayList
    public static void createAppointment(String patientName, String phoneNumber, String preferedTimeSlot, HealthProfessional doctor)
    {
        if (patientName.isEmpty() || phoneNumber.isEmpty() || preferedTimeSlot.isEmpty() || doctor == null)
        {
            System.out.println("Error: Missing required information. Appointment cannot be created.");
            return;
        }

        Appointment appointment = new Appointment(patientName, phoneNumber, preferedTimeSlot, doctor);
        appointments.add(appointment);
        System.out.println("Appointment created successfully.");     
    }

    //Print existing appointments
    public static void printExistingAppointments()
    {
        if(appointments.isEmpty())
        {
            System.out.println("No existing appoingmnet.");
            return;
        }

        for(Appointment appointment : appointments)
        {
            appointment.printAppointmentDetails();
        }
    }

    //Cancel reservation throuhh mobile phone number
    public static void cancelBooking(String phoneNumber)
    {
        boolean found = false;

        for(int i = 0; i < appointments.size(); i++)
        {
            if(appointments.get(i).getPhoneNumber().endsWith(phoneNumber))
            {
                appointments.remove(i);
                System.out.println("Appointment with phone number " + phoneNumber + "has been cancelled.");
                found = true;
                break;
            }      
        }

        if(!found)
            {
                System.out.println("No appointment found with phone number " + phoneNumber);
            }
    }
}
