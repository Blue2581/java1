//My Github link : https://github.com/Blue2581/java1 
//Notice that : You need to use a vpn to visit Github link
//Created a HealthProfessional class in the base class for part 1 task
package base; // HealthProfessional class is in base package ( New change )
public class HealthProfessional 
{
    private int ID; 
    //Required instance variable ID
    private String name;
    //Required instance variable name
    private String basicInfo;
    //Basic information unrelated to the type of doctor

    public HealthProfessional() 
    {
        //The default constructor of the first function 
        this.ID = 0;
        this.name = "";
        this.basicInfo = "";
        //In this method, default values can be set for these three variables. ("Null" is also ok)
       
    }

    public HealthProfessional(int ID, String name, String basicInfo) 
    {
        //The second function , Initialize all instance variables
        this.ID = ID;
        this.name = name;
        this.basicInfo = basicInfo;

    }

    public void printInfo()
    {
        System.out.println("ID :" +this.ID);
        System.out.println("name :" +this.name);
        System.out.println("basciInfo :" +this.basicInfo);
        //This method can output the values of all variables : ID, name and basciInfo
    }

}
