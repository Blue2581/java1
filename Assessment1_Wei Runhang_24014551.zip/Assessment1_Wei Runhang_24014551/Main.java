import base.HealthProfessional;
import child.Dentist;
import child.GeneralPractitioner;
import java.util.ArrayList;
import java.util.Scanner;
//My Github link : https://github.com/Blue2581/java1 

public class Main {

    // Part 5-Collection of appointments
    private static ArrayList<Appointment> appointments = new ArrayList<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // 创建一些医生对象
        GeneralPractitioner gp = new GeneralPractitioner(101, "Dr. Alice", "Family Medicine Specialist", "Family Medicine");
        Dentist dentist = new Dentist(201, "Dr. Bob", "Expert in dental care", "Bright Smile Clinic");

        // 创建并添加一些默认预约
        createAppointment("John Doe", "123-456-7890", "09:00-10:00", gp);
        createAppointment("Jane Smith", "987-654-3210", "14:00-15:00", dentist);

        // 打印现有预约
        System.out.println("Existing Appointments:");
        printExistingAppointments();

        System.out.println("---------");

        // 用户交互：创建新预约
        System.out.println("Do you want to create a new appointment? (yes/no)");
        String response = scanner.nextLine();
        if (response.equalsIgnoreCase("yes")) {
            System.out.print("Enter patient name: ");
            String patientName = scanner.nextLine();

            System.out.print("Enter phone number: ");
            String phoneNumber = scanner.nextLine();

            System.out.print("Enter preferred time slot: ");
            String preferredTimeSlot = scanner.nextLine();

            System.out.print("Choose doctor type (1 for General Practitioner, 2 for Dentist): ");
            int doctorChoice = scanner.nextInt();
            scanner.nextLine(); // 清空换行符

            HealthProfessional doctor = null;
            if (doctorChoice == 1) {
                doctor = gp;
            } else if (doctorChoice == 2) {
                doctor = dentist;
            } else {
                System.out.println("Invalid doctor choice.");
            }

            if (doctor != null) {
                createAppointment(patientName, phoneNumber, preferredTimeSlot, doctor);
            }
        }

        System.out.println("---------");

        // 打印所有预约
        System.out.println("All Appointments:");
        printExistingAppointments();

        System.out.println("---------");

        // 用户交互：取消预约
        System.out.print("Enter phone number to cancel booking: ");
        String cancelPhoneNumber = scanner.nextLine();
        cancelBooking(cancelPhoneNumber);

        System.out.println("---------");

        // 打印取消后的预约
        System.out.println("Appointments after cancellation:");
        printExistingAppointments();

        scanner.close();
    }

    // 创建新的预约并添加到 ArrayList 中
    public static void createAppointment(String patientName, String phoneNumber, String preferredTimeSlot, HealthProfessional doctor) {
        if (patientName.isEmpty() || phoneNumber.isEmpty() || preferredTimeSlot.isEmpty() || doctor == null) {
            System.out.println("Error: Missing required information. Appointment cannot be created.");
            return;
        }

        Appointment appointment = new Appointment(patientName, phoneNumber, preferredTimeSlot, doctor);
        appointments.add(appointment);
        System.out.println("Appointment created successfully.");
    }

    // 打印现有的预约
    public static void printExistingAppointments() {
        if (appointments.isEmpty()) {
            System.out.println("No existing appointments.");
            return;
        }

        for (Appointment appointment : appointments) {
            appointment.printAppointmentDetails();
        }
    }

    // 通过手机号码取消预约
    public static void cancelBooking(String phoneNumber) {
        boolean found = false;

        for (int i = 0; i < appointments.size(); i++) {
            if (appointments.get(i).getPhoneNumber().equals(phoneNumber)) {
                appointments.remove(i);
                System.out.println("Appointment with phone number " + phoneNumber + " has been cancelled.");
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("No appointment found with phone number " + phoneNumber);
        }
    }
}
