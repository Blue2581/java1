import base.HealthProfessional;
import child.GeneralPractitioner;
//import 3 classes

public class Appointment
{
    private String PatientName;
    private String PhoneNumber;
    private String PreferredTimeSlot;
    //Difine variables for patient name, phone number , appointment time
    private HealthProfessional doctor;
    //Quoting the variable from HealthProfessional forndoctor information

    public Appointment()
    {
        //Default constructor
        this.PatientName = PatientName;
        this.PhoneNumber = PhoneNumber;
        this.PreferredTimeSlot = PreferredTimeSlot;
        this.doctor = null;
    }

    public Appointment(String PatientName, String PhoneNumber, String PreferredTimeSlot, HealthProfessional doctor)
    {
        this.PatientName = PatientName;
        this.PhoneNumber = PhoneNumber;
        this.PreferredTimeSlot = PreferredTimeSlot;
        this.doctor = doctor;
    }

    public void printAppointmentDetails()
    {
        System.out.println("Patient Name :" +PatientName);
        System.out.println("Phone :" +PhoneNumber);
        System.out.println("Prefer time slot :" +PreferredTimeSlot);
        //Print the patients personal information first
        if( doctor != null)
        {
            System.out.println("Doctor information :");
            doctor.printInfo();
        }
        else
        {
            System.out.println("No doctor can be selected now !");
        }
        System.out.println("--------");
        //After that , using if statement to print the doctors details , if the valua is null , the patient can not select doctor
    }

    public String getPhoneNumber()
    {
        return PhoneNumber;
        //Getters for getting the phone number
    }

    public static void main(String args[])
    {
        //Create object and appointments here ( Existing information )
        GeneralPractitioner gpx = new GeneralPractitioner(523, "Max","Family Medicine Specialist", "Family Medicine");
        Appointment apx = new Appointment("Sarah","13241432","7:00 - 10 ;00", gpx);
        System.out.println("Appointments for patients information is here :");
        apx.printAppointmentDetails();
    }



}
